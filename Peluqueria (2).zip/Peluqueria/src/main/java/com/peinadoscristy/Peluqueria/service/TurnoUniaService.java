package com.peinadoscristy.Peluqueria.service;

import com.peinadoscristy.Peluqueria.model.EstadoTurno;
import com.peinadoscristy.Peluqueria.model.ServicioUnia;
import com.peinadoscristy.Peluqueria.model.TurnoUnia;
import com.peinadoscristy.Peluqueria.repository.TurnoUniaRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.time.*;
import java.util.ArrayList;
import java.util.List;

@Service
@RequiredArgsConstructor
public class TurnoUniaService {

    private final TurnoUniaRepository turnoUniaRepository;

    /**
     * Devuelve todos los horarios disponibles (1 persona por horario)
     * en slots de 90 minutos.
     */
    public List<LocalTime> obtenerHorariosDisponibles(LocalDate fecha) {

        DayOfWeek dow = fecha.getDayOfWeek();
        if (dow == DayOfWeek.MONDAY || dow == DayOfWeek.SUNDAY) {
            return List.of();
        }

        List<LocalTime> slots = generarSlots(fecha);

        List<TurnoUnia> turnosDelDia =
                turnoUniaRepository.findByFechaAndEstadoNot(fecha, EstadoTurno.CANCELADO);

        List<LocalTime> disponibles = new ArrayList<>();

        for (LocalTime slot : slots) {
            boolean ocupado = turnosDelDia.stream()
                    .anyMatch(t -> t.getHoraInicio() != null && t.getHoraInicio().equals(slot)
                            && t.getEstado() != EstadoTurno.CANCELADO);

            if (!ocupado) {
                disponibles.add(slot);
            }
        }

        return disponibles;
    }

    /**
     * Slots de 90 minutos, con el mismo horario de trabajo que peluquería.
     */
    private List<LocalTime> generarSlots(LocalDate fecha) {
        List<LocalTime> result = new ArrayList<>();
        DayOfWeek dow = fecha.getDayOfWeek();

        if (dow == DayOfWeek.SATURDAY) {
            agregarTramo(result, LocalTime.of(8, 30), LocalTime.of(20, 0), 90);
        } else {
            agregarTramo(result, LocalTime.of(8, 30), LocalTime.of(12, 30), 90);
            agregarTramo(result, LocalTime.of(15, 0), LocalTime.of(20, 0), 90);
        }

        return result;
    }

    private void agregarTramo(List<LocalTime> lista, LocalTime inicio, LocalTime fin, int minutosPaso) {
        LocalTime actual = inicio;
        while (!actual.isAfter(fin)) {
            lista.add(actual);
            actual = actual.plusMinutes(minutosPaso);
        }
    }

    // ===== CRUD =====

    public TurnoUnia guardar(TurnoUnia turno) {
        if (turno.getEstado() == null) {
            turno.setEstado(EstadoTurno.PENDIENTE);
        }
        return turnoUniaRepository.save(turno);
    }

    public BigDecimal calcularPrecio(ServicioUnia servicio) {
        if (servicio == null) return BigDecimal.ZERO;
        return BigDecimal.valueOf(servicio.getPrecioBase());
    }
}
