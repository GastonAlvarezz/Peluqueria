package com.peinadoscristy.Peluqueria.model;

public enum EstadoTurno {
    PENDIENTE,
    CONFIRMADO,
    CANCELADO
}
