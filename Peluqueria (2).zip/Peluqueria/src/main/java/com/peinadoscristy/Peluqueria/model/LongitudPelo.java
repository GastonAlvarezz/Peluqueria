package com.peinadoscristy.Peluqueria.model;

public enum LongitudPelo {
    CORTO,
    MEDIO,
    LARGO
}
