package com.peinadoscristy.Peluqueria.model;

public enum TipoPelo {
    LACIO,
    ONDULADO,
    RIZADO,
    MUY_ABUNDANTE
}
